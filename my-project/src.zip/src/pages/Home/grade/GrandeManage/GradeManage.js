import React from 'react';
import {connect} from "dva";
function GradeManage(){
    return (
        <div>班级管理</div>
    )

}

GradeManage.propTypes={

}

export default connect()(GradeManage)