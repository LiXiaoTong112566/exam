import React from 'react';
import {connect} from "dva";
function AwaitClass(){
    return (
        <div>待批班级</div>
    )

}

 AwaitClass.propTypes={

}

export default connect()( AwaitClass)